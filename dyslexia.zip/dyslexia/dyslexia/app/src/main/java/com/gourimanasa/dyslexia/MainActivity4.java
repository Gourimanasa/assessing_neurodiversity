package com.gourimanasa.dyslexia;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
//import android.view.View;
//import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
//import android.widget.Toast;
public class MainActivity4 extends AppCompatActivity {

    private EditText editText;
    private TextView textViewTime;
    private TextView textViewResult;
    private Button buttonStart;
    public Button buttonReset;
    private int timeLeft = 60;
    private int charactersTyped = 0;
    private int wordsTyped = 0;
    private boolean timerRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();

        editText = findViewById(R.id.editText);
        textViewTime = findViewById(R.id.textViewTime);
        textViewResult = findViewById(R.id.textViewResult);
        buttonStart = findViewById(R.id.buttonStart);
        buttonReset = findViewById(R.id.buttonReset);

       buttonStart.setOnClickListener(v -> startTimer());

        buttonReset.setOnClickListener(v -> resetTimer());

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateResult(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    public void startTimer() {
        if (!timerRunning) {

            timerRunning = true;
            buttonStart.setEnabled(false);
        }
    }

    public void resetTimer() {
        timeLeft = 60;
        charactersTyped = 0;
        wordsTyped = 0;
        timerRunning = false;
        updateTimer();
        updateResult("");
        editText.setText("");
        buttonStart.setEnabled(true);
    }

    @SuppressLint("SetTextI18n")
    private void updateTimer() {
        textViewTime.setText("Time: " + timeLeft);
    }

    @SuppressLint("DefaultLocale")
    private void updateResult(String text) {
        String[] words = text.trim().split("\\s+");
        charactersTyped = text.length();
        wordsTyped = words.length;
        textViewResult.setText(String.format("%s%d Words: %d", getString(R.string.characters), charactersTyped, wordsTyped));
    }
}
