package com.gourimanasa.dyslexia;

public class Words {
    public static String words[]={
            "hello",
            "how",
            "where"
    };
}
