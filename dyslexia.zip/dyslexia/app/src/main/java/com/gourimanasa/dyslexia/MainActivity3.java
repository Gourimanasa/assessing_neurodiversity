package com.gourimanasa.dyslexia;
import static android.support.v4.content.ContextCompat.startActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
//import android.view.View;


public class MainActivity3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
    }
    public void next1(View view){
        Intent intent=new Intent(this,MainActivity4.class);
        startActivity(intent);
    }
}

