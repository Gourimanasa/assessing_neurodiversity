package com.gourimanasa.dyslexia;

import android.app.AlertDialog;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity5 extends AppCompatActivity implements View.OnClickListener{
    TextView total_questions;
    TextView question;
    Button op1,op2,op3,op4;
    Button submit;
    int score=0;
    int totalQuestion=QuestionAnswer.question.length;
    int currentQuestionIndex=0;
    String selectedAnswer="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        total_questions=findViewById(R.id.textView5);
        question=findViewById(R.id.textView6);
        op1=findViewById(R.id.button8);
        op2=findViewById(R.id.button10);
        op3=findViewById(R.id.button11);
        op4=findViewById(R.id.button12);
        submit=findViewById(R.id.button13);
        op1.setOnClickListener(this);
        op2.setOnClickListener(this);
        op3.setOnClickListener(this);
        op4.setOnClickListener(this);
        submit.setOnClickListener(this);
        total_questions.setText("Total question:"+totalQuestion);
        loadNewQuestion();
    }

    @Override
    public void onClick(View view) {
        op1.setBackgroundColor(Color.WHITE);
        op2.setBackgroundColor(Color.WHITE);
        op3.setBackgroundColor(Color.WHITE);
        op4.setBackgroundColor(Color.WHITE);
        Button clickedButton=(Button)  view;
        if(clickedButton.getId()==R.id.button13) {
            if(selectedAnswer.equals(QuestionAnswer.correctAnswers[currentQuestionIndex])){
                score++;
            }
            currentQuestionIndex++;
            loadNewQuestion();
        }else{
             selectedAnswer = clickedButton.getText().toString();
             clickedButton.setBackgroundColor(Color.MAGENTA);
        }


    }
    public void loadNewQuestion(){
        if(currentQuestionIndex==totalQuestion){
            finishQuiz();
            return;
        }
        total_questions.setText(QuestionAnswer.question[currentQuestionIndex]);
        op1.setText(QuestionAnswer.choices[currentQuestionIndex][0]);
        op2.setText(QuestionAnswer.choices[currentQuestionIndex][1]);
        op3.setText(QuestionAnswer.choices[currentQuestionIndex][2]);
        op4.setText(QuestionAnswer.choices[currentQuestionIndex][3]);
    }
    void finishQuiz(){
        String passStatus="";
        if(score>totalQuestion*0.60){
            passStatus="passed";

        }
        else{
            passStatus="failed";
        }
        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score is "+score+"out of"+totalQuestion)
                .setPositiveButton("restart",(dialogInterface,i)->restartQuiz())
                .setCancelable(false)
                .show();
    }
    void restartQuiz(){
        score=0;
        currentQuestionIndex=0;
        loadNewQuestion();

    }
}