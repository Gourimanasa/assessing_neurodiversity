package com.gourimanasa.dyslexia;

public class QuestionAnswer {
        public static String[] question ={
                "What is 13+4 and 13x4?",
                "What is 91+16",
                "What is 96+69?",
                "What is 12-6 and 12/6 and 12+6 and 12*6?",
                "What is 16-9 and 16+9",
                "give the count of 2 from the given 1223226227228762"

        };
        public static String[][] choices ={
                {"17 52","52,17","16 72","none"},
                {"105","106","107","108"},
                {"156","157","165","176"},
                {"7 25 72 2","7 2 18 72","none","both 1 and 2 are correct"},
                {"7 25","25 7","13 25","25 13"},
                {"7","8","9","10"}

        };
        public static String[] correctAnswers ={
                "17 52",
                "107",
                "165",
                "7 2 18 72",
                "7 25"

        };

    }

