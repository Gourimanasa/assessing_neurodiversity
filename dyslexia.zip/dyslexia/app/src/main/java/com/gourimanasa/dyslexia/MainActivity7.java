package com.gourimanasa.dyslexia;
//import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity7 extends AppCompatActivity {
    TextView text1,text2;
    EditText text3;
    String fullStory;
    long StartTime;
    long EndTime;
    boolean GameStarted=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        text1=(TextView) findViewById(R.id.textView10);
        text2=(TextView) findViewById(R.id.textView11);
        text3=(EditText)findViewById(R.id.editTextTextPersonName);
        Button b1 = (Button) findViewById(R.id.button15);
        fullStory=text1.getText().toString();
                text3.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }
                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String currentStory=text3.getText().toString();
                        if(currentStory.length()==1 && !GameStarted){
                            StartTime=System.currentTimeMillis();
                            text2.setText("Started");
                            GameStarted=true;
                        }
                        if(currentStory.equals(fullStory)){
                            EndTime=System.currentTimeMillis();
                            long currentTime=(EndTime-StartTime)/1000;
                            text2.setText("finished in "+currentTime+"seconds");
                            text3.setEnabled(false);
                            text3.clearFocus();
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
               b1.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       text3.setEnabled(true);
                       text3.setText("");
                       text2.setText("");
                       GameStarted=false;

                   }
               });
    }
}
