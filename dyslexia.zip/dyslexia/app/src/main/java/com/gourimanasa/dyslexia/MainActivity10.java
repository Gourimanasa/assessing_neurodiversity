package com.gourimanasa.dyslexia;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity10 extends AppCompatActivity {
    EditText email = findViewById(R.id.editTextTextPersonName2);
    EditText password=findViewById(R.id.editTextTextPersonName3);
    Button submit=findViewById(R.id.button17);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
            }
        });

    }
}